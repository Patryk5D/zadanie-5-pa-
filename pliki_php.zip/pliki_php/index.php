<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Moje pliki</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<h1>MOJE PLIKI</h1>

<p>Aktualny katalog:</p>

<?php echo getcwd(); ?>

<h2>ZAWARTOŚĆ KATALOGU</h2>

<table>
    <tr>
        <th>Nazwa</th>
        <th>Typ</th>
    </tr>

<?php
$pliki = scandir("dokumenty");

foreach ($pliki as $plik):
    if ($plik != "." && $plik != ".."):
?>

    <tr>
        <td><?php echo $plik; ?></td>

        <td>
            <?php
            if (is_file("dokumenty/" . $plik)) {
                echo "PLIK";
            }

            if (is_dir("dokumenty/" . $plik)) {
                echo "KATALOG";
            }
            ?>
        </td>
    </tr>

<?php
    endif;
endforeach;
?>

</table>

<h2>TWORZENIE KATALOGU</h2>

<form method="post">
    <input type="text" name="nazwa">
    <button type="submit">Utwórz</button>
</form>

<?php
if (isset($_POST["nazwa"]) && $_POST["nazwa"] != "") {

    $nowy = "dokumenty/" . $_POST["nazwa"];

    if (!file_exists($nowy)) {
        mkdir($nowy);
        echo "Katalog został utworzony.";
    } else {
        echo "Taki katalog już istnieje.";
    }
}
?>

</body>
</html>